﻿Public Class categoriavb
    Private Sub CategoriaBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CategoriaBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CategoriaBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.InventoryDB1DataSet)

    End Sub

    Private Sub categoriavb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'InventoryDB1DataSet.Categoria' Puede moverla o quitarla según sea necesario.
        Me.CategoriaTableAdapter.Fill(Me.InventoryDB1DataSet.Categoria)
        Me.CategoriaBindingSource.AddNew()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Hide()
        Menuprincipal.Show()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        salir.Show()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        IdcatTextBox.Text = ""
        NombrecatTextBox.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If IdcatTextBox.Text = "" Or NombrecatTextBox.Text = "" Then
            MsgBox("No pueden haber campos vacíos")
        Else
            Me.CategoriaBindingSource.EndEdit()
            Me.CategoriaTableAdapter.Update(InventoryDB1DataSet)
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.CategoriaBindingSource.RemoveCurrent()

    End Sub
End Class