﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Materialvb
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IdmatLabel As System.Windows.Forms.Label
        Dim NombrematLabel As System.Windows.Forms.Label
        Dim CantidadLabel As System.Windows.Forms.Label
        Dim DescripcionmatLabel As System.Windows.Forms.Label
        Dim CategoriaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Materialvb))
        Me.InventoryDB1DataSet = New Inventory.InventoryDB1DataSet()
        Me.MaterialBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MaterialTableAdapter = New Inventory.InventoryDB1DataSetTableAdapters.MaterialTableAdapter()
        Me.TableAdapterManager = New Inventory.InventoryDB1DataSetTableAdapters.TableAdapterManager()
        Me.MaterialBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.MaterialDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IdmatTextBox = New System.Windows.Forms.TextBox()
        Me.NombrematTextBox = New System.Windows.Forms.TextBox()
        Me.CantidadTextBox = New System.Windows.Forms.TextBox()
        Me.DescripcionmatTextBox = New System.Windows.Forms.TextBox()
        Me.Categoria = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.MaterialBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        IdmatLabel = New System.Windows.Forms.Label()
        NombrematLabel = New System.Windows.Forms.Label()
        CantidadLabel = New System.Windows.Forms.Label()
        DescripcionmatLabel = New System.Windows.Forms.Label()
        CategoriaLabel = New System.Windows.Forms.Label()
        CType(Me.InventoryDB1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaterialBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaterialBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MaterialBindingNavigator.SuspendLayout()
        CType(Me.MaterialDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IdmatLabel
        '
        IdmatLabel.AutoSize = True
        IdmatLabel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IdmatLabel.ForeColor = System.Drawing.SystemColors.HotTrack
        IdmatLabel.Location = New System.Drawing.Point(124, 92)
        IdmatLabel.Name = "IdmatLabel"
        IdmatLabel.Size = New System.Drawing.Size(86, 14)
        IdmatLabel.TabIndex = 2
        IdmatLabel.Text = "ID Material:"
        '
        'NombrematLabel
        '
        NombrematLabel.AutoSize = True
        NombrematLabel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NombrematLabel.ForeColor = System.Drawing.SystemColors.HotTrack
        NombrematLabel.Location = New System.Drawing.Point(124, 118)
        NombrematLabel.Name = "NombrematLabel"
        NombrematLabel.Size = New System.Drawing.Size(64, 14)
        NombrematLabel.TabIndex = 4
        NombrematLabel.Text = "Nombre:"
        '
        'CantidadLabel
        '
        CantidadLabel.AutoSize = True
        CantidadLabel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CantidadLabel.ForeColor = System.Drawing.SystemColors.HotTrack
        CantidadLabel.Location = New System.Drawing.Point(124, 144)
        CantidadLabel.Name = "CantidadLabel"
        CantidadLabel.Size = New System.Drawing.Size(70, 14)
        CantidadLabel.TabIndex = 6
        CantidadLabel.Text = "Cantidad:"
        '
        'DescripcionmatLabel
        '
        DescripcionmatLabel.AutoSize = True
        DescripcionmatLabel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DescripcionmatLabel.ForeColor = System.Drawing.SystemColors.HotTrack
        DescripcionmatLabel.Location = New System.Drawing.Point(124, 170)
        DescripcionmatLabel.Name = "DescripcionmatLabel"
        DescripcionmatLabel.Size = New System.Drawing.Size(89, 14)
        DescripcionmatLabel.TabIndex = 8
        DescripcionmatLabel.Text = "Descripción:"
        '
        'CategoriaLabel
        '
        CategoriaLabel.AutoSize = True
        CategoriaLabel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CategoriaLabel.ForeColor = System.Drawing.SystemColors.HotTrack
        CategoriaLabel.Location = New System.Drawing.Point(124, 196)
        CategoriaLabel.Name = "CategoriaLabel"
        CategoriaLabel.Size = New System.Drawing.Size(76, 14)
        CategoriaLabel.TabIndex = 10
        CategoriaLabel.Text = "Categoria:"
        '
        'InventoryDB1DataSet
        '
        Me.InventoryDB1DataSet.DataSetName = "InventoryDB1DataSet"
        Me.InventoryDB1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MaterialBindingSource
        '
        Me.MaterialBindingSource.DataMember = "Material"
        Me.MaterialBindingSource.DataSource = Me.InventoryDB1DataSet
        '
        'MaterialTableAdapter
        '
        Me.MaterialTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.MaterialTableAdapter = Me.MaterialTableAdapter
        Me.TableAdapterManager.UpdateOrder = Inventory.InventoryDB1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UsuarioTableAdapter = Nothing
        '
        'MaterialBindingNavigator
        '
        Me.MaterialBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.MaterialBindingNavigator.BindingSource = Me.MaterialBindingSource
        Me.MaterialBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.MaterialBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.MaterialBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.MaterialBindingNavigatorSaveItem, Me.ToolStripSeparator1})
        Me.MaterialBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.MaterialBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.MaterialBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.MaterialBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.MaterialBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.MaterialBindingNavigator.Name = "MaterialBindingNavigator"
        Me.MaterialBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.MaterialBindingNavigator.Size = New System.Drawing.Size(674, 25)
        Me.MaterialBindingNavigator.TabIndex = 0
        Me.MaterialBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'MaterialDataGridView
        '
        Me.MaterialDataGridView.AutoGenerateColumns = False
        Me.MaterialDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MaterialDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.MaterialDataGridView.DataSource = Me.MaterialBindingSource
        Me.MaterialDataGridView.Location = New System.Drawing.Point(44, 257)
        Me.MaterialDataGridView.Name = "MaterialDataGridView"
        Me.MaterialDataGridView.Size = New System.Drawing.Size(546, 220)
        Me.MaterialDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "idmat"
        Me.DataGridViewTextBoxColumn1.HeaderText = "idmat"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "nombremat"
        Me.DataGridViewTextBoxColumn2.HeaderText = "nombremat"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "cantidad"
        Me.DataGridViewTextBoxColumn3.HeaderText = "cantidad"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "descripcionmat"
        Me.DataGridViewTextBoxColumn4.HeaderText = "descripcionmat"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "categoria"
        Me.DataGridViewTextBoxColumn5.HeaderText = "categoria"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'IdmatTextBox
        '
        Me.IdmatTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MaterialBindingSource, "idmat", True))
        Me.IdmatTextBox.Location = New System.Drawing.Point(219, 90)
        Me.IdmatTextBox.Name = "IdmatTextBox"
        Me.IdmatTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IdmatTextBox.TabIndex = 3
        '
        'NombrematTextBox
        '
        Me.NombrematTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MaterialBindingSource, "nombremat", True))
        Me.NombrematTextBox.Location = New System.Drawing.Point(219, 116)
        Me.NombrematTextBox.Name = "NombrematTextBox"
        Me.NombrematTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NombrematTextBox.TabIndex = 5
        '
        'CantidadTextBox
        '
        Me.CantidadTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MaterialBindingSource, "cantidad", True))
        Me.CantidadTextBox.Location = New System.Drawing.Point(219, 142)
        Me.CantidadTextBox.Name = "CantidadTextBox"
        Me.CantidadTextBox.Size = New System.Drawing.Size(100, 20)
        Me.CantidadTextBox.TabIndex = 7
        '
        'DescripcionmatTextBox
        '
        Me.DescripcionmatTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MaterialBindingSource, "descripcionmat", True))
        Me.DescripcionmatTextBox.Location = New System.Drawing.Point(219, 168)
        Me.DescripcionmatTextBox.Name = "DescripcionmatTextBox"
        Me.DescripcionmatTextBox.Size = New System.Drawing.Size(100, 20)
        Me.DescripcionmatTextBox.TabIndex = 9
        '
        'Categoria
        '
        Me.Categoria.FormattingEnabled = True
        Me.Categoria.Items.AddRange(New Object() {"Limpieza", "Obra", "Mantenimiento", "Oficina", "Otros"})
        Me.Categoria.Location = New System.Drawing.Point(219, 197)
        Me.Categoria.Name = "Categoria"
        Me.Categoria.Size = New System.Drawing.Size(100, 21)
        Me.Categoria.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label1.Location = New System.Drawing.Point(258, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(172, 32)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Materiales"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(475, 85)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(115, 28)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Añadir"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button3.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(475, 119)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(115, 28)
        Me.Button3.TabIndex = 15
        Me.Button3.Text = "Eliminar"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(475, 153)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(115, 28)
        Me.Button4.TabIndex = 16
        Me.Button4.Text = "Limpiar"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button5.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(204, 500)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(115, 28)
        Me.Button5.TabIndex = 17
        Me.Button5.Text = "Inicio"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button6.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(367, 500)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(115, 28)
        Me.Button6.TabIndex = 18
        Me.Button6.Text = "Salir"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'MaterialBindingNavigatorSaveItem
        '
        Me.MaterialBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.MaterialBindingNavigatorSaveItem.Image = CType(resources.GetObject("MaterialBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.MaterialBindingNavigatorSaveItem.Name = "MaterialBindingNavigatorSaveItem"
        Me.MaterialBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.MaterialBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'Materialvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(674, 540)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Categoria)
        Me.Controls.Add(IdmatLabel)
        Me.Controls.Add(Me.IdmatTextBox)
        Me.Controls.Add(NombrematLabel)
        Me.Controls.Add(Me.NombrematTextBox)
        Me.Controls.Add(CantidadLabel)
        Me.Controls.Add(Me.CantidadTextBox)
        Me.Controls.Add(DescripcionmatLabel)
        Me.Controls.Add(Me.DescripcionmatTextBox)
        Me.Controls.Add(CategoriaLabel)
        Me.Controls.Add(Me.MaterialDataGridView)
        Me.Controls.Add(Me.MaterialBindingNavigator)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Materialvb"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Materialvb"
        CType(Me.InventoryDB1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaterialBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaterialBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MaterialBindingNavigator.ResumeLayout(False)
        Me.MaterialBindingNavigator.PerformLayout()
        CType(Me.MaterialDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents InventoryDB1DataSet As InventoryDB1DataSet
    Friend WithEvents MaterialBindingSource As BindingSource
    Friend WithEvents MaterialTableAdapter As InventoryDB1DataSetTableAdapters.MaterialTableAdapter
    Friend WithEvents TableAdapterManager As InventoryDB1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents MaterialBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents MaterialBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents MaterialDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents IdmatTextBox As TextBox
    Friend WithEvents NombrematTextBox As TextBox
    Friend WithEvents CantidadTextBox As TextBox
    Friend WithEvents DescripcionmatTextBox As TextBox
    Friend WithEvents Categoria As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
End Class
