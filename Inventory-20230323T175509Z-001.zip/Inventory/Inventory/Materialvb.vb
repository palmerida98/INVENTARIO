﻿Public Class Materialvb
    Private Sub MaterialBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles MaterialBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.MaterialBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.InventoryDB1DataSet)

    End Sub

    Private Sub Materialvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'InventoryDB1DataSet.Material' Puede moverla o quitarla según sea necesario.
        Me.MaterialTableAdapter.Fill(Me.InventoryDB1DataSet.Material)
        Me.MaterialBindingSource.AddNew()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        salir.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If IdmatTextBox.Text = "" Or NombrematTextBox.Text = "" Or CantidadTextBox.Text = "" Or DescripcionmatTextBox.Text = "" Or Categoria.SelectedItem = "" Then
            MsgBox("No pueden haber campos en blanco")
        Else
            Me.MaterialBindingSource.EndEdit()
            Me.MaterialTableAdapter.Update(InventoryDB1DataSet)
            MsgBox("Registrado con éxito")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        IdmatTextBox.Text = ""
        NombrematTextBox.Text = ""
        CantidadTextBox.Text = ""
        DescripcionmatTextBox.Text = ""
        Categoria.SelectedItem = ""

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Hide()
        Menuprincipal.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.MaterialBindingSource.RemoveCurrent()

    End Sub
End Class