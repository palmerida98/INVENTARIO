﻿Public Class clientevb
    Private Sub ClienteBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClienteBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClienteBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.InventoryDB1DataSet)

    End Sub

    Private Sub clientevb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'InventoryDB1DataSet.Cliente' Puede moverla o quitarla según sea necesario.
        Me.ClienteTableAdapter.Fill(Me.InventoryDB1DataSet.Cliente)
        Me.ClienteBindingSource.AddNew()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Hide()
        Menuprincipal.Show()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        salir.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If CedulaclienteTextBox.Text = "" Or NombreclienteTextBox.Text = "" Or TelefonoclienteTextBox.Text = "" Then
            MsgBox("No pueden haber campos vacíos")
        Else
            Me.ClienteBindingSource.EndEdit()
            Me.ClienteTableAdapter.Update(InventoryDB1DataSet)
            CedulaclienteTextBox.Text = ""
            NombreclienteTextBox.Text = ""
            TelefonoclienteTextBox.Text = ""
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.ClienteBindingSource.RemoveCurrent()
        CedulaclienteTextBox.Text = ""
        NombreclienteTextBox.Text = ""
        TelefonoclienteTextBox.Text = ""
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        CedulaclienteTextBox.Text = ""
        NombreclienteTextBox.Text = ""
        TelefonoclienteTextBox.Text = ""
    End Sub
End Class