﻿Public Class Menuprincipal
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        salir.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Materialvb.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        clientevb.Show()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        categoriavb.Show()

    End Sub
End Class