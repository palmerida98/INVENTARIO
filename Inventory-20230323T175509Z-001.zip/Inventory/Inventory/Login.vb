﻿Public Class Login
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If usertb.Text = "plcsg" And passwordtb.Text = "123456" Then
            Me.Hide()
            Menuprincipal.Show()
            MsgBox("Bienvenido")
        Else
            MsgBox("Datos incorrectos")
            usertb.Text = ""
            passwordtb.Text = ""
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        salir.Show()

    End Sub
End Class